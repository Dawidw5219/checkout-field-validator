# Checkout Field Validator

wp i18n make-pot . languages/checkout-field-validator.pot --no-location
